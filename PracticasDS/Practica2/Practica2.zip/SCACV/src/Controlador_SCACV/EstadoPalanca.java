/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador_SCACV;

/**
 *
 * @author Marina
 */
public enum EstadoPalanca {
    APAGADO,REINICIAR,ACELERAR,MANTENER
}

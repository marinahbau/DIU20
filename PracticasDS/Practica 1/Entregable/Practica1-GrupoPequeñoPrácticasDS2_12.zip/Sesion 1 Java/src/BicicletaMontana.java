public class BicicletaMontana extends Bicicleta {
        
        BicicletaMontana(int _id){
            super(_id);
        }
}
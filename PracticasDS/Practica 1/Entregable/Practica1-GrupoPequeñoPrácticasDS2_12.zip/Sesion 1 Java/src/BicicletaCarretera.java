public class BicicletaCarretera extends Bicicleta {

	BicicletaCarretera(int _id){
            super(_id);
        }
}